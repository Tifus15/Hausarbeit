/**
 * 
 * @author Denis Andric
 *
 */
public class Regula {

	/**
	 * Diese Methode is Funktion log(x) aus Uebungsaufgabe
	 * 
	 * @param x
	 *            Eine Variable der Funktion
	 * @return Funktionswert
	 */
	public double f(double x) {
		return Math.pow(x, 3);
	}

	/**
	 * Regula Falosrum methode
	 * 
	 * @param a
	 *            linkes Punkt der intervall wo Nullstelle liegt
	 * @param b
	 *            rechtes Punkt fer Interwal wo Nullstelle liegt
	 * @param e
	 *            epsilon kleine positive Zahl
	 * @return Nullstelle
	 */
	public double executeRegula(double a, double b, double e) {

		double x = a;
		double x1;

		do {
			x1 = x;
			x = (f(b) * a - f(a) * b) / (f(b) - f(a));

			if (f(a) * f(b) * f(x) <= 0)
				b = x;

			else
				a = x;

		} while (Math.abs(x - x1) >= e);

		return x;
	}

	public double modExecuteRegula(double a, double b, double e) {

		double F = f(a);
		double G = f(b);
		double x1;
		double x = a;

		do {
			x1 = x;
			x = (G * a - F * b) / (G - F);

			if (f(a) * f(b) * f(x) <= 0) {
				b = x;
				G = f(x);
				if (f(x) * f(x1) > 0)
					F = F / 2;

			} else {
				a = x;
				F = f(x);
				if (f(x) * f(x1) > 0)
					G = G / 2;
			}

		} while (Math.abs(x - x1) > e);

		return x;
	}

	public static void main(String[] args) {

		Regula regula = new Regula();
		regula.executeRegula(-1, 2, 0.000000001);// 792858 Iterationen
		System.out.println();
		regula.modExecuteRegula(-1, 2, 0.000000001);// 58 Iterationen

	}

}
