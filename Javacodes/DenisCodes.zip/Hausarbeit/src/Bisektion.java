
public class Bisektion {

	public double f(double x) {
		return Math.log(x);
	}
/**
 * Methode um eine Nullstelle zu finden in Interval [a,b] - Bisektionalgorithmus
 * @param a aus Interval [a,b]
 * @param b aus Interval [a,b]
 * @param e sehr kleinen Zahl f�r Abruchkriterium
 * @return approximierte Nullstelle der Funktion auf gegebenen Interval
 */
	public double executeBisektion(double a, double b, double e) {
		double x;

		do {

			x = (a + b) / 2;

			if (f(a) * f(x) < 0)
				b = x;

			else
				a = x;

		} while (Math.abs(b-a) > e);//Intervalllaenge

		return x;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bisektion bisektion = new Bisektion();
		bisektion.executeBisektion(-4, 5, 0);
	}

}
