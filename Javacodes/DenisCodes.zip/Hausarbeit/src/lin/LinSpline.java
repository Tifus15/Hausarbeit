package lin;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class LinSpline {
	public Data[] a;

	public LinSpline(Data[] a) {

		this.a = a;
	}

	public static Data[] loadData(String a) {
		File c = new File(a);
		BufferedReader in = null;
		Data[] data = new Data[8];
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(c), "UTF8"));
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String r;
		String r1;
		String r2;
		int i = 0;

		try {
			while ((r = in.readLine()) != null) {
				r1 = r.substring(0, 3);
				r2 = r.substring(3);
				data[i] = new Data(Double.parseDouble(r1.trim()), Double.parseDouble(r2.trim()));
				i++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

	/* Verbessern */
	public double Li(int i, double x) {
		if (i > 0) {
			if (((x >= a[i - 1].getXi()) && (x <= a[i].getXi())))
				return (x - a[i - 1].getXi()) / (a[i].getXi() - a[i - 1].getXi());
		} else if ((x >= a[i].getXi()) && (x <= a[i + 1].getXi()))
			return (a[i + 1].getXi() - x) / (a[i + 1].getXi() - a[i].getXi());
		else
			return 0;
		return 0;

	}

	public double GLi(int i, double x) {
		System.out.println(a[i].getGi() + " * " + Li(i, x) + " + " + a[i + 1].getGi() + " * " + Li(i + 1, x));
		return (a[i].getGi() * Li(i, x)) + (a[i + 1].getGi() * Li(i + 1, x));
	}

	public static void main(String[] args) throws IOException {
		LinSpline lineareSpline = new LinSpline(loadData("daten.txt"));
		//etwas schiff lauft wegen Li
		System.out.println(lineareSpline.Li(1, 10) + " " + lineareSpline.Li(2, 10) + " " + lineareSpline.Li(3, 40));
		System.out.println(lineareSpline.GLi(0, 10) + " " + lineareSpline.GLi(0, 0) + " " + lineareSpline.GLi(0, 1.8));
	}

}
