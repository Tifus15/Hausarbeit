package lin;

public class Data {
	private double xi;
	private double Gi;

	public Data(double d, double gi) {

		xi = d;
		Gi = gi;
	}

	public double getXi() {
		return xi;
	}

	public void setXi(double xi) {
		this.xi = xi;
	}

	public double getGi() {
		return Gi;
	}

	public void setGi(double gi) {
		Gi = gi;
	}

}
