package lin;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.LinkedList;

public class LinSpline {
	public Data[] a;

	public LinSpline(Data[] a) {

		this.a = a;
	}

	public static Data[] loadData(String a) {
		File c = new File(a);
		BufferedReader in = null;
		Data[] data = new Data[8];
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(c), "UTF8"));
		} catch (UnsupportedEncodingException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String r;
		String r1;
		String r2;
		int i = 0;

		try {
			while ((r = in.readLine()) != null) {
				r1 = r.substring(0, 3);
				r2 = r.substring(3);
				data[i] = new Data(Double.parseDouble(r1.trim()), Double.parseDouble(r2.trim()));
				i++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

	/**
	 * Implementierung eines linearen Splines: Gibt den Wert des Splines L_i an
	 * der Stelle x zur�ck
	 * 
	 * @param i
	 *            Index der Stelle, an der der Spline sein Maximum hat
	 * @param x
	 *            Argument der Splinefunktion
	 * @return Wert der Splinefunktion an der Stelle x
	 * @throws IllegalArgumentException
	 *             Der Index i muss zwischen 0 und der Anzahl der Datenpunkte -
	 *             1 sein.
	 */
	public double singleSpline(int i, double x) throws IllegalArgumentException {
		if (i < 0 || i >= a.length)
			throw new IllegalArgumentException("i must be between 0 and a.length - 1");
		if (i >= 0 && i <= a.length - 2 && x >= a[i].getXi() && x <= a[i + 1].getXi())
			return (a[i + 1].getXi() - x) / (a[i + 1].getXi() - a[i].getXi());
		if (i >= 1 && i <= a.length - 1 && x >= a[i - 1].getXi() && x <= a[i].getXi())
			return (x - a[i - 1].getXi()) / (a[i].getXi() - a[i - 1].getXi());
		return 0;
	}

	/**
	 * Implementierung eines gewichteten linearen Splines: Gibt den Wert des mit
	 * dem Wert an der Stelle x_i multiplizierten Splines L_i an der Stelle x
	 * zur�ck
	 * 
	 * @param i
	 *            Index der Stelle, an der der Spline sein Maximum hat
	 * @param x
	 *            Argument der gewichteten Splinefunktion
	 * @return Wert der gewichteten Splinefunktion an der Stelle x
	 * @throws IllegalArgumentException
	 *             Der Index i muss zwischen 0 und der Anzahl der Datenpunkte -
	 *             1 sein.
	 */
	public double weightedSpline(int i, double x) throws IllegalArgumentException {
		if (i < 0 || i >= a.length)
			throw new IllegalArgumentException("i must be between 0 and a.length - 1");
		return a[i].getGi() * singleSpline(i, x);
	}

	/**
	 * Gibt den Wert des interpolierenden Splines (der gesamten st�ckweise
	 * definierten Funktion) an der Stelle x zur�ck.
	 * 
	 * @param x
	 *            Argument des interpolierenden Splines
	 * @return Wert des interpolierenden Splines
	 */
	public double interpolierenderSpline(double x) {
		double sum = 0;
		for (int i = 0; i < a.length; i++)
			sum += weightedSpline(i, x);
		return sum;
	}
    /**
     * Gibt eine Liste der lokalen Extrema aus den array data was Knoten der weighted Spline entschpricht 
     * @return List der lokalen Extrema
     */
	public LinkedList<Data> findMaxima() {
		LinkedList<Data> linkedlist = new LinkedList<Data>();
		for (int i = 1; i < a.length - 2; i++) {
			if ((a[i - 1].getGi() < a[i].getGi()) && (a[i].getGi() > a[i + 1].getGi())) {
				linkedlist.add(new Data(a[i].getXi(), a[i].getGi()));
			}

		}
		return linkedlist;
	}



	public static void main(String[] args) throws IOException {
		LinSpline lineareSpline = new LinSpline(loadData("daten.txt"));
		// etwas schiff lauft wegen Li - IMMER NOCH?
		System.out.println(lineareSpline.singleSpline(1, 10) + " " + lineareSpline.singleSpline(2, 10) + " "
				+ lineareSpline.singleSpline(3, 35));
		System.out.println(lineareSpline.interpolierenderSpline(42.5));
		// System.out.println(lineareSpline.GLi(0, 10) + " " +
		// lineareSpline.GLi(0, 0) + " " + lineareSpline.GLi(0, 1.8));
	}

}
