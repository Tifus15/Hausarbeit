package Splines;

public class Data {
	private double argument, value;
	public Data (double a, double v) {
		argument = a;
		value = v;
	}
	public double getArgument() {
		return argument;
	}
	public void setArgument(double argument) {
		this.argument = argument;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
}
