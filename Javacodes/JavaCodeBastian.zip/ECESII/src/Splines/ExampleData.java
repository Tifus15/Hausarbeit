package Splines;

public class ExampleData {
	public static final Data[] EXAMPLEDATA = new Data[] {new Data(0, -20), new Data(10, 100), new Data(20, 260), new Data(30, 400), new Data(45, 441.25), new Data(50, 380), new Data(60, 100)};
}
